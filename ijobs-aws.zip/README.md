# Job-Application
Job Application is a web based system which helps companies get most empowered and skilled man power. It also helps job applicants to find a company of interest and apply for a job.
 ## Link to Trello board https://trello.com/b/DMloMHzM/ijobs
